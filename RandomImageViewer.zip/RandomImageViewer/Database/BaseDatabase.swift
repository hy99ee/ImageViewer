//
//  BaseDatabase.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 22.12.2021.
//
import RealmSwift

protocol BaseDatabase{
    func write<T:Hashable>(_ object:T)
    func convertInputObject<T:Hashable>(_ object:T) -> Object?
    func updateObjects()
}
