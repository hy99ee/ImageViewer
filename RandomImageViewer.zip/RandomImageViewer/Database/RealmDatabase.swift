//
//  RealmDatabase.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 22.12.2021.
//

import Foundation
import RealmSwift


final class RealmDatabase: BaseDatabase{

    private let realm:Realm = try! Realm()
    var objects: Results<RealmDatabaseObject>?
    
    init(){
        updateObjects()
    }
    
    func convertInputObject<T:Hashable>(_ object:T) -> Object? {
        guard let unsplash = object as? UnsplashPhotoModel else {return nil}
        let convertObject = RealmDatabaseObject(id: unsplash.id, downloads: unsplash.downloads, likes: unsplash.likes, descriptionImage: unsplash.description, defaultUrl: unsplash.defaultUrl)

        return convertObject
    }
    
    func write<T:Hashable>(_ object:T){
        guard let unsplashObject = object as? UnsplashPhotoModel else {return}
        try! realm.write({
            if let object = convertInputObject(unsplashObject){
                realm.add(object)
            }
        })
        updateObjects()
    }
    
    
    func updateObjects(){
        objects = realm.objects(RealmDatabaseObject.self)
    }
     
    
    func removeLastElement(){
        try! realm.write({
            if let object = objects?.last{
                realm.delete(object)
            }
        })
        updateObjects()
    }
}

