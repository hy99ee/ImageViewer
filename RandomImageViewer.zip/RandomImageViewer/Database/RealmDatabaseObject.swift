//
//  RealmDatabaseObject.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 22.12.2021.
//
import RealmSwift

class RealmDatabaseObject: Object{
    
    @objc dynamic var id:String = ""
    @objc dynamic var downloads:Int = 0
    @objc dynamic var likes:Int = 0
    @objc dynamic var descriptionImage:String = ""
    @objc dynamic var defaultUrl:String?
//    @objc dynamic var image:NSData = NSData()
    
//    override static func primaryKey() -> String? {
//        return "id"
//    }
    
    override init() {
        super.init()
    }
    
    required init(id: String, downloads: Int, likes: Int, descriptionImage: String, defaultUrl: String?) {
        self.id = id
        self.downloads = downloads
        self.likes = likes
        self.descriptionImage = descriptionImage
        self.defaultUrl = defaultUrl
    }
}

//public protocol Persistable {
//    associatedtype ManagedObject: RealmSwift.Object
//    init(managedObject: ManagedObject)
//    func managedObject() -> ManagedObject
//}


//struct DisplayData : Persistable{
//    var id = ""
//    var downloads = ""
//    var likes = ""
//    var descriptionImage = ""
//
//    public init(managedObject: RealmDatabaseObject) {
//        id = managedObject.id
//        downloads = managedObject.downloads
//        likes = managedObject.likes
//        descriptionImage = managedObject.descriptionImage
//    }
//    public func managedObject() -> RealmDatabaseObject {
//        let character = RealmDatabaseObject()
//        character.id = id
//        character.downloads = downloads
//        character.likes = likes
//        character.descriptionImage = descriptionImage
//        return character
//    }
//}
