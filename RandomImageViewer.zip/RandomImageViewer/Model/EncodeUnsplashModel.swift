//
//  EncodeUnsplashModel.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 22.12.2021.
//

import Foundation
import RealmSwift

// Syntactic sugar
extension KeyedDecodingContainer {
    public func decode<T: Decodable>(_ key: Key, as type: T.Type = T.self) throws -> T {
        return try self.decode(T.self, forKey: key)
    }
}
// Add self init for decode photo
extension UnsplashPhotoModel : Decodable {
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: UnsplashPhotoCodingKeys.self)
        
        // decode values from container
        id = try container.decode(UnsplashPhotoCodingKeys.id)
        downloads = try container.decode(UnsplashPhotoCodingKeys.downloads)
        likes = try container.decode(UnsplashPhotoCodingKeys.likes)
        description = try container.decode(UnsplashPhotoCodingKeys.description)
        urls = try container.decode(UnsplashPhotoCodingKeys.urls, as: [URLSizes.RawValue:String].self)
        defaultUrl = urls?["regular"]
        
    }
    
    // CodingKeys for decode data from UrlRequst
    private enum UnsplashPhotoCodingKeys: CodingKey{
        case id
        case downloads
        case likes
        case description
        case urls
    }
}
