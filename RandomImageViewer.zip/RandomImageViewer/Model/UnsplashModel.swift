//
//  PhotoDataModel.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 10.12.2021.
//

import Foundation

struct UnsplashPhotoModel : Hashable {
    
    let id: String
    let downloads:Int
    let likes:Int
    let description:String
    let urls:[URLSizes.RawValue:String]?
    let defaultUrl:String?
    
    enum URLSizes:String{
        case taw
        case full
        case regular
        case small
        case thumb
    }
    
}

