//
//  ImageLoader.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 22.12.2021.
//

import SwiftUI
import Combine

final class ImageLoader: ObservableObject{
    private let key = "lastImage"
    @Published var image:UIImage?{
        didSet{
            saveLastImage()
        }
    }
    var url:URL?
    
    
    var lastImage: UIImage?{
        if let imageData = UserDefaults.standard.object(forKey: key) as? Data,
            let image = UIImage(data: imageData) {
            return image
        }
        else {return nil}
    }
    
    func load(){
        guard let url = url else {return}
        
        URLSession.shared.dataTaskPublisher(for: url)
            .map{ UIImage(data: $0.data) }
            .replaceError(with: nil)
            .receive(on: DispatchQueue.main)
            .assign(to: &$image)
    }
    
    private func saveLastImage(){
        DispatchQueue.global(qos: .background).async { [weak self] in
            if let image = self?.image ,let pngRepresentation = image.pngData() {
                print(pngRepresentation)
                UserDefaults.standard.set(pngRepresentation, forKey: self?.key ?? "")
            }
        }
    }
}
