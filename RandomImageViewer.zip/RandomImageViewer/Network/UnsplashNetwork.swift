//
//  UnsplashRequestCreator.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 19.12.2021.
//

import Foundation
final class UnsplashNetwork{
    
    let accesKey = "Z4aq3hmlyIEkLR6I6Io0_lHWSUJpMuUQegrm8sZZtD4"
    let secretKey = "mps2h_lVLXgTdHVOF17wVhVkqlu3y00Dm1BzWNwOd0E"
    
    struct AdressComponents{
        let schema:String
        let host:String
        let path:String
    }
    private var adressComponents:AdressComponents!
    private var url:URL!
    var urlRequest:URLRequest{
        adressComponents = AdressComponents(schema: "https", host: "api.unsplash.com", path: "/photos/random")
        url = createUrl (params: prepareParams())
        return createGetUrlRequestByUrl(url)
    }
    

    
    private func createGetUrlRequestByUrl(_ url:URL) -> URLRequest{
        var request = URLRequest(url: url)
        request.allHTTPHeaderFields = prepareHeaders()
        request.httpMethod = "get"
        return request
    }
    
    private func createUrl(params : [String:String]) -> URL{
        var components = URLComponents()
        components.scheme = adressComponents.schema
        components.host = adressComponents.host
        components.path = adressComponents.path
        components.queryItems = params.map{
            URLQueryItem(name: $0, value: $1)
        }
        return components.url!
    }
    
    private func prepareHeaders() -> [String:String]?{
        var headers = [String:String]()
        headers["Authorization"] = String("Client-ID \(accesKey)")
        return headers
    }
    private func prepareParams() -> [String:String]{
        var params = [String:String]()
        params["orientation"] = "squarish"
        
        return params
    }
}
