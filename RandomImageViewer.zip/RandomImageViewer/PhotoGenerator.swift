//
//  PhotoGenerator.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 19.12.2021.
//

import Foundation
import Combine
import RealmSwift

final class PhotoGenerator: ObservableObject{
    
    @Published var currentPhoto:UnsplashPhotoModel?
    @Published var currentImageURLString:String?
    private var cancellable:AnyCancellable?
    private var database:RealmDatabase
    
    init(){
        database = RealmDatabase()
    }
    
    func fetchRandomImage(){
        cancellable = URLSession.shared.dataTaskPublisher(for: UnsplashNetwork().urlRequest)
            .receive(on: DispatchQueue.main)
            .sink { _ in
        } receiveValue: { (data, _) in
            if let photoData = try? JSONDecoder().decode(UnsplashPhotoModel.self, from: data){
                self.currentPhoto = photoData
                self.currentImageURLString = photoData.defaultUrl
//                if self.currentPhoto != nil {
//                    self.database.write(self.currentPhoto!)
//                }
            }
        }
    }
    
    func addImageToFavorite(){
        if currentPhoto != nil{
            self.database.write(currentPhoto!)
        }
    }
    
    func removeLastImage(){
        database.removeLastElement()
    }
    
    func removeFavoriteImage(at indexSet: IndexSet){
        
    }
    
    func favoritesImagesData() -> [UnsplashPhotoModel]{
        var unsplashPhotoList:[UnsplashPhotoModel] = []
        guard let objects = database.objects else {return unsplashPhotoList}
        unsplashPhotoList = objects.compactMap{ object in
            let model = UnsplashPhotoModel(id: object.id, downloads: object.downloads, likes: object.likes, description: object.descriptionImage, urls: nil, defaultUrl: object.defaultUrl)
            return model
        }
        return unsplashPhotoList
    }
    
}
