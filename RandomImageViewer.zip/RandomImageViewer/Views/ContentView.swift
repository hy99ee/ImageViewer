//
//  ContentView.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 19.12.2021.
//

import SwiftUI

struct ContentView: View {
    @State var timeRemaining = 10
    @StateObject private var photoGenerator = PhotoGenerator()
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    @State private var countdownTimerView = CountdownTimerView(seconds:5)
    
    var body: some View {
        TabView{
            
            ScrollView{
                AsyncImageView(urlString: $photoGenerator.currentImageURLString).scaledToFill()

                ContentPhotoView(photoModel: photoGenerator.currentPhoto)
                Spacer()
                
                FavoritesMarkView(actionOn :photoGenerator.addImageToFavorite, actionOff:photoGenerator.removeLastImage )
                //TODO: replace this code!
                countdownTimerView
                    .onReceive(countdownTimerView.timer) { _ in
                        if timeRemaining > 0 {
                            timeRemaining -= 1
                        }
                        else{
                            photoGenerator.fetchRandomImage()
                            timeRemaining = 5
                            
                        }
                    }
                    
                    
                
            }
            .padding()
            .tabItem {
                Image(systemName: "globe")
                Text("Explore")
            }
            
            FavoritesListView(photoGenerator: photoGenerator)
                .tabItem{
                    Image(systemName: "star")
                    Text("Favorites")
                }
            
        }
        
    }
    
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
