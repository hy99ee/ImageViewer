//
//  FavoritesListView.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 22.12.2021.
//

import Foundation
import SwiftUI

struct FavoritesListView: View{
//    @StateObject private var imagesLoader = ImagesLoader()
    let photoGenerator:PhotoGenerator
    init(photoGenerator:PhotoGenerator){
        self.photoGenerator = photoGenerator
    }
    
    
    var body: some View {
        NavigationView{
            List {
                ForEach(photoGenerator.favoritesImagesData(), id: \.self) { model in
                    VStack{
                        MainView(model: model)
                    }
                }.onDelete(perform: photoGenerator.removeFavoriteImage)
                    .onAppear {
                        //update 
                    }
                
            }
            
        }
    }
        
}


struct MainView: View{
    let model:UnsplashPhotoModel
    init(model:UnsplashPhotoModel){
        self.model = model
    }
    var body: some View{
        NavigationLink(destination:OpenImageView(model: model)){
            FavoriteImage(
                url: URL(string: model.defaultUrl!)!,
                placeholder: { Text("Loading ...") },
                image: { Image(uiImage: $0).resizable() }
            ) .frame(width: 150, height: 100)
            VStack(alignment: .leading, spacing: 8) {
                Text(model.id)
                    .bold()
                    .font(.subheadline)
                    .lineLimit(1)
                Text("The Happy Programmer")
                    .font(.caption2)
                    .foregroundColor(Color.gray)
                HStack {
                    Text(String(format: "DOWNLOADS"))
                        .font(.caption2)
                        .foregroundColor(Color.gray)
                }
            }
        }
    }
}


struct OpenImageView: View {
    
    let model:UnsplashPhotoModel
    
    init(model:UnsplashPhotoModel){
        self.model = model
    }
    
    var body: some View{
        ScrollView{
            FavoriteImage(
                url: URL(string: model.defaultUrl!)!,
                placeholder: { Text("Loading ...") },
                image: { Image(uiImage: $0).resizable() }
            ) .scaledToFill()
            
            ContentPhotoView(photoModel:model)
            Spacer()
        }
    }
}

//
//struct SimpleListView: View {
//
//    @State var d = Data()
//
//    var body: some View {
//        NavigationView {
//            List {
//                ForEach(d, id: \.self) { m in
//                    VStack {
//                        NavigationLink(destination: Text(m.title)) {
//                            HStack{
//                                Image(m.Image)
//                                    .resizable()
//                                    .frame(width: 120, height: 90)
//                                VStack(alignment: .leading, spacing: 8) {
//                                    tags(tags: m.postType)
//                                    Text(m.title)
//                                        .bold()
//                                        .font(.subheadline)
//                                        .lineLimit(1)
//                                    Text("The Happy Programmer")
//                                        .font(.caption2)
//                                        .foregroundColor(Color.gray)
//                                    HStack {
//                                        ProgressView(value: m.percentage)
//                                            .progressViewStyle(LinearProgressViewStyle(tint: Color.pinkColor))
//                                            .foregroundColor(Color.red)
//                                        Text(String(format: "%.0f%%", m.percentage * 100))
//                                            .font(.caption2)
//                                            .foregroundColor(Color.gray)
//                                    }
//                                }
//                            }
//                        }
//                    }
//                }.onDelete(perform: {})
//            }.listStyle(DefaultListStyle())
//            .navigationTitle("Posts")
//        }
//    }
//}
