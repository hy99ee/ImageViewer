//
//  FavoritesMarkView.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 23.12.2021.
//
import SwiftUI

struct FavoritesMarkView: View {
    @State var isActive = false
    private let actionOn:()->Void
    private let actionOff:()->Void
    init(actionOn:@escaping ()->Void, actionOff: @escaping ()->Void){
        self.actionOn = actionOn
        self.actionOff = actionOff
    }
    var body: some View {
        ZStack {
            Color.white
            Button(action: {
                self.isActive.toggle()
                isActive ? actionOn() : actionOff()
            }) {
                HStack {
                    Image(systemName: isActive ? "star.fill" : "star")
                        .foregroundColor(isActive ? Color.yellow : Color.gray )
                    Text(isActive ? "Remove from favorites" : "Add to favorites")
                }
            }
            .padding()
        }
    }
}
