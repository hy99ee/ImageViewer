//
//  AcyncImageView.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 19.12.2021.
//

import SwiftUI
import Combine

struct AsyncImageView: View{
    @StateObject private var imageLoader = ImageLoader()
    @Binding var urlString: String?
    
    init(urlString: Binding<String?>){
        self._urlString = urlString
    }
    
    var image: some View {
        Group {
            if let image = imageLoader.image{
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(10)
            } else if let image = imageLoader.lastImage{
                Image(uiImage: image)
                    .resizable()
                    .scaledToFit()
                    .cornerRadius(10)
            }
            else {
                Text("No image")
            }
        }
    }
    var body: some View{
        image.onChange(of: urlString) { _ in
            guard let urlString = urlString, let url = URL(string: urlString) else {return}
                imageLoader.url = url
                imageLoader.load()
            }
        
    }
}
