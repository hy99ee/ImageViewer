//
//  ContentPhotoView.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 21.12.2021.
//

import Foundation
import SwiftUI
import AuthenticationServices

struct ContentPhotoView: View{

    var photoModel:UnsplashPhotoModel?
    var isDescription:Bool
    let font = Font.system(size: 30)

    init(photoModel:UnsplashPhotoModel?, isDescription:Bool = true){
        self.photoModel = photoModel
        self.isDescription = isDescription
    }
    
    var body: some View{
        if photoModel != nil{
//            Text("ID = \(photoModel!.id)")
            
            Text("Downdloads = \(photoModel!.downloads)").font(font).bold()
            Text("Likes: \(photoModel!.likes)").font(font).bold()
            ScrollView{
                Text(isDescription ? "Decription: \(photoModel!.description)" : "...").italic()
            }
        }
    }
    
}
