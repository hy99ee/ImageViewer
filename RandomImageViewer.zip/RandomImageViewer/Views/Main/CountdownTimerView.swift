//
//  ChangeImageTimer.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 21.12.2021.
//

import Foundation
import SwiftUI

struct CountdownTimerView: View {

    private let timerFont = Font.custom("DBLCDTempBlack", size: 50)
    private let defaultSeconds:Int
    @State var remainingSeconds: Int
    @State var finishTimer = false
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    var body: some View {
        VStack {
            Text("\(getTimeString(from: remainingSeconds))")
                .onReceive(timer) { _ in
                    if remainingSeconds > 0 {
                        finishTimer = true
                        remainingSeconds -= 1
                    } else {
                        remainingSeconds = defaultSeconds
                    }
                }.font(timerFont)
        }.padding()
        

    }
    
    init(seconds: Int) {
        defaultSeconds = seconds
        _remainingSeconds = State(initialValue: seconds)
    }
    

    
    private func getTimeString(from totalSeconds: Int) -> String {
        let hours = totalSeconds / 3600
        let minutes = totalSeconds / 60 % 60
        let seconds = totalSeconds % 60
        return String(format:"%02i:%02i:%02i", hours, minutes, seconds)
    }
    
}



struct CountdownTimerView_Previews: PreviewProvider {
    static var previews: some View {
        CountdownTimerView(seconds: 40)
    }
}
