//
//  RandomImageViewerApp.swift
//  RandomImageViewer
//
//  Created by Hy99ee on 19.12.2021.
//

import SwiftUI

@main
struct RandomImageViewerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
